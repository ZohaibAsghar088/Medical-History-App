---
name: Clinical Clarity
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#747686'
  outline-variant: '#c4c5d7'
  surface-tint: '#2151da'
  primary: '#0037b0'
  on-primary: '#ffffff'
  primary-container: '#1d4ed8'
  on-primary-container: '#cad3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#004870'
  on-tertiary: '#ffffff'
  tertiary-container: '#006194'
  on-tertiary-container: '#b2d9ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001551'
  on-primary-fixed-variant: '#0039b5'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-lg: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an empathetic, clinically rigorous, and reassuring presence for a personal health repository. The interface balances institutional healthcare precision with the warmth of a daily wellness companion. 

### Target Audience & Psychology
The experience serves individuals, caregivers, and chronically ill patients who frequently encounter stress, cognitive overload, and fragmented health documentation. The UI prioritizes visual calm, high-legibility typographic hierarchies, effortless scanability, and instant reassurance of data security and synchronization.

### Design Movement: Modern Clinical
Drawing from modern software aesthetics and refined human-centered medical design:
- **Calm Foundations:** Generous, breathable layouts resting on balanced slate undertones rather than sterile, stark whites.
- **Structured Density:** Information is categorized into digestible, bite-sized visual units using modular cards, timeline tracks, and semantic tags.
- **Tactile Trust:** Tactile surfaces, clear boundary delineations through hairline neutral borders, and responsive state transitions that eliminate ambiguity during critical data entry.

## Colors

The color palette reinforces medical integrity, cognitive ease, and immediate semantic comprehension.

### Palette Architecture
- **Primary (`#1D4ED8`):** Deep cobalt blue conveying institutional trust, security, and definitive interactive elements such as main CTAs and active states.
- **Secondary (`#0D9488`):** Soothing medical teal, utilized for auxiliary highlights, vital stats, preventive health indicators, and wellness context.
- **Tertiary (`#0284C7`):** Vivid cyan-sky blue for dynamic updates, informational chips, and active record sync notices.
- **Neutral Canvas & Surfaces:**
  - Base Background: `#F8FAFC` (Slate 50) creates a soft, warm-neutral backdrop that reduces glare and eye strain.
  - Secondary Canvas / Inset Wells: `#F1F5F9` (Slate 100).
  - Primary Surface: `#FFFFFF` for pristine, legible elevated cards and modal sheets.
  - Border Hairline: `#E2E8F0` (Slate 200) for clean card and divider demarcation.
  - Slate Typography Ladder: `#0F172A` (Slate 900) for primary text; `#334155` (Slate 700) for secondary details; `#64748B` (Slate 500) for metadata and supporting notes.

### Semantic Status Indicators
- **Emerald Active / Synced (`#059669`):** Stable vitals, active prescriptions, and encrypted sync confirmation.
- **Amber Attention / Follow-up (`#D97706`):** Pending doctor reviews, upcoming renewals, and scheduled lab appointments.
- **Rose Urgent (`#DC2626`):** Critical allergy warnings, urgent contraindications, and expired vitals thresholds.

## Typography

Plus Jakarta Sans is utilized across all typographic levels. Its friendly, geometric proportions offer immediate warmth while retaining crisp mechanical clarity across clinical values, dosages, lab metric names, and doctor notes.

### Hierarchy & Guidelines
- **Numerical Values:** Tabular figures are used for all physiological metrics (e.g., blood pressure, blood glucose, heart rate) to prevent jitter during real-time filtering and scanning.
- **Hierarchy Distinction:** Section headers rely on `title-lg` and `title-md` in semi-bold (`600`) weight, pairing with `body-md` in regular (`400`) weight to maintain rapid skim-reading efficiency for patients.
- **Labels & Badges:** `label-sm` is reserved for uppercase clinical status flags, timeline category chips, and prescription intake schedules.

## Layout & Spacing

The layout is built for mobile ergonomics centered around a 390px reference screen (iOS / Android), accommodating safe-area insets seamlessly.

### Layout Rhythm
- **Canvas Margins:** Screen boundaries utilize an outer horizontal margin of `1rem` (16px) scaling to `1.25rem` (20px) on wider phones to maximize touch targets while keeping cards spacious.
- **Vertical Rhythm:** Information groupings (e.g., Timeline sections, Health Profile categories) are structured with `1.5rem` (24px) gaps between card groups and `0.75rem` (12px) between sibling items inside a record list.
- **Touch Safe Zones:** Interactive items respect a strict minimum touch boundary of 48×48px. Form controls and action triggers guarantee at least `0.75rem` vertical separation to prevent mis-taps by users with motor impairments.

## Elevation & Depth

Visual hierarchy uses a refined hybrid approach: crisp, hairline borders combined with soft ambient light-source shadows. This ensures legibility under varied mobile lighting environments (including direct sunlight).

### Surface Layers
- **Level 0 (Canvas Base):** Flat `#F8FAFC`. Zero elevation, zero shadow.
- **Level 1 (Card & Modular Records):** `#FFFFFF` surface with a 1px solid border in `#E2E8F0` and an ambient drop shadow: `0px 2px 8px -2px rgba(15, 23, 42, 0.05)`.
- **Level 2 (Popovers, Active Focus Cards, Sticky Timeline Headers):** `#FFFFFF` surface, 1px solid `#CBD5E1`, with shadow: `0px 8px 16px -4px rgba(15, 23, 42, 0.08)`.
- **Level 3 (Floating Action Button & Bottom Navigation):** Raised above scrolling content. Shadow: `0px 12px 24px -6px rgba(29, 78, 216, 0.15)` for primary buttons, and `0px -4px 16px 0px rgba(15, 23, 42, 0.04)` for the bottom nav bar.

## Shapes

The geometric signature uses friendly, organic rounds that soften clinical data without feeling juvenile.

### Radius Implementations
- **Cards & Sheets (`1rem` / 16px - `1.25rem` / 20px):** Medical record entries, lab reports, doctor contact summaries, and modal bottom sheets utilize generous 16px to 20px corners (`rounded-lg` to `rounded-xl`).
- **Input Fields & Form Selectors (`0.75rem` / 12px):** Structured inputs and dropdown selectors apply soft 12px corners.
- **Pills & Chips (9999px / Full Radius):** Metric status indicators, record tags, category chips, and bottom navigation indicator capsules strictly leverage complete capsule pill profiles.

## Components

### Buttons
- **Primary Action Button:** Solid `#1D4ED8` fill, `#FFFFFF` text, 48px height, 12px radius, centered icon paired with `label-lg`. Pressed state drops brightness to `#1E40AF`.
- **Secondary Action Button:** Surface in `#F1F5F9`, border 1px solid `#E2E8F0`, text in `#0F172A`.
- **Floating Action Button (FAB):** 56×56px circle or pill-extended shape (`+ Record`), colored `#1D4ED8` with a vibrant soft shadow (`rgba(29, 78, 216, 0.25)`).

### Medical Record Cards
- Constructed with `#FFFFFF` background, 16px border radius, 1px `#E2E8F0` border, and 16px internal padding.
- Card header contains record category icon, record title, and a right-aligned pill badge.
- Body displays key diagnostics or metrics in bold tabular figures.
- Footer features a subtle hairline separator leading to metadata (e.g., date, physician name, hospital facility).

### Status Badges & Chips
- Fully rounded pills (height: 24px, horizontal padding: 10px).
- **Active / Normal:** Background `#ECFDF5`, text `#065F46`, optional 6px emerald dot indicator.
- **Follow-up / Attention:** Background `#FFFBEB`, text `#92400E`, optional 6px amber dot indicator.
- **Critical / Allergy:** Background `#FEF2F2`, text `#991B1B`, optional 6px rose dot indicator.

### Timeline Connectors
- Vertical connecting line: 2px solid `#CBD5E1`.
- Timeline Nodes: 12px circular node with a 3px white ring and primary or teal fill, aligning with the primary title baseline of each record card.

### Input Fields & Controls
- **Text Inputs:** Height 52px, background `#FFFFFF`, border 1.5px solid `#E2E8F0`, corner radius 12px, placeholder in `#94A3B8`. Focused state transitions border to `#1D4ED8` with a 3px outer glow `rgba(29, 78, 216, 0.12)`.
- **Checkboxes & Radios:** 22×22px, active color `#1D4ED8` with crisp white checkmark glyphs. Minimum tap target expanded to 48×48px with transparent padding.

### Bottom Navigation Bar
- Fixed height: 68px (plus device safe area), background `#FFFFFF`, bordered with 1px `#E2E8F0` top stroke.
- Selected item features an active capsule pill indicator (`#EFF6FF`), rendering the icon and label in `#1D4ED8`. Inactive items rest in `#64748B`.